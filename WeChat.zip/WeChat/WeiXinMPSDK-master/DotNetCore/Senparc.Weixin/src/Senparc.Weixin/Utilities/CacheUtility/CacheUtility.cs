﻿/*----------------------------------------------------------------
    Copyright (C) 2016 Senparc

    文件名：CacheUtility.cs
    文件功能描述：缓存工具类


    创建标识：Senparc - 20160318

----------------------------------------------------------------*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Senparc.Weixin.CacheUtility
{
    /// <summary>
    /// 缓存工具类
    /// </summary>
    public class CacheUtility
    {
    }

}
