.NET Core 版本
================

本文件件用于存放 .NET Core 版本beta代码。
项目基本建立之后，将会创建独立的 .NET Core 版本分支。
