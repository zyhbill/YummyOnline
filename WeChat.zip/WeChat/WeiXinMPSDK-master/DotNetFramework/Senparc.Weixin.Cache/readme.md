分布式缓存扩展方案
=========
1、Senparc.Weixin.Cache.Memcached：Memcached缓存框架策略

2、Senparc.Weixin.Cache.Redis:Redis缓存框架策略
