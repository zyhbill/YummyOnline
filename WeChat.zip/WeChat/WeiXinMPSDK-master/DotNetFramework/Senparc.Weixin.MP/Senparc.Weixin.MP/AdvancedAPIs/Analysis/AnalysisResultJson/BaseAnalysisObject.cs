﻿/*----------------------------------------------------------------
    Copyright (C) 2016 Senparc
    
    文件名：BaseAnalysisObject.cs
    文件功能描述：分析数据接口返回结果Object基类
    
    
    创建标识：Senparc - 20150309
    
    修改标识：Senparc - 20150310
    修改描述：整理接口
----------------------------------------------------------------*/

namespace Senparc.Weixin.MP.AdvancedAPIs.Analysis
{
    public interface IBaseAnalysisObject
    {
    }

    public class BaseAnalysisObject : IBaseAnalysisObject
    {
        public BaseAnalysisObject()
        {
        }
    }
}
