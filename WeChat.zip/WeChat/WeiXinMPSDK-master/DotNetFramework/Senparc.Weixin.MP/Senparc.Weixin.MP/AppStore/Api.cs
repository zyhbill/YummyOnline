﻿namespace Senparc.Weixin.MP.AppStore
{
    //public static class Api
    //{
    //    public static IResponseMessageBase Request(IMessageHandler messageHandler, DeveloperInfo developerInfo, string xml)
    //    {
    //        var responseMessage = MessageAgent.RequestWeiweihiResponseMessage(messageHandler, developerInfo.WeiweihiKey, messageHandler.RequestMessage as RequestMessageBase);

    //        return responseMessage;
    //    }
    //}
}
