﻿/*----------------------------------------------------------------
    Copyright (C) 2016 Senparc
  
    文件名：Config.cs
    文件功能描述：调试设置
    
    
    创建标识：Senparc - 20150319
----------------------------------------------------------------*/

namespace Senparc.Weixin.MP.AppStore
{
    public static class Config
    {
        public static bool IsDebug = false;
    }
}
